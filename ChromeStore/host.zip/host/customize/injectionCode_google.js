
alert("sample of injection code");
