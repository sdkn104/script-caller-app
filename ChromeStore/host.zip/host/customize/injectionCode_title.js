

let main = function() {
    return {title: document.querySelector("title").innerHTML};
};
main();

